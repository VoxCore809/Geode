Make sure to extract the zip file before running Geode

You must download Microsoft Visual C++ Redistributable & .NET 8.0 to make Geode run properly.

Open these links below to download them:
https://learn.microsoft.com/en-us/cpp/windows/latest-supported-vc-redist?view=msvc-170
https://dotnet.microsoft.com/en-us/download/dotnet/8.0

Microsoft Visual C++ Redistributable is optional as this zip file already provides it, it is still recommended to download it.

If Geode does not open at all after having those dependencies installed, run .NET 8.0 installer then select the repair option. That is a problem with .NET